import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assignment',
  templateUrl: './fra-assignment.component.html',
  styleUrls: ['./fra-assignment.component.css']
})
export class FraAssignmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

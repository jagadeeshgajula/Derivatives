import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-partial-assignment',
  templateUrl: './fra-partial-assignment.component.html',
  styleUrls: ['./fra-partial-assignment.component.css']
})
export class FraPartialAssignmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-additional-fields',
  templateUrl: './fra-additional-fields.component.html',
  styleUrls: ['./fra-additional-fields.component.css']
})
export class FraAdditionalFieldsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

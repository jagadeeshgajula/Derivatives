import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fees',
  templateUrl: './fra-fees.component.html',
  styleUrls: ['./fra-fees.component.css']
})
export class FraFeesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-margin',
  templateUrl: './fra-margin.component.html',
  styleUrls: ['./fra-margin.component.css']
})
export class FraMarginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

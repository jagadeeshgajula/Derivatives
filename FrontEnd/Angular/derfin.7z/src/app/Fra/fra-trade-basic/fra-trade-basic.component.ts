import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trade-basic',
  templateUrl: './fra-trade-basic.component.html',
  styleUrls: ['./fra-trade-basic.component.css']
})
export class FraTradeBasicComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

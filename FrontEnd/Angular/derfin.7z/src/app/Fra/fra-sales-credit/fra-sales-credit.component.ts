import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-credit',
  templateUrl: './fra-sales-credit.component.html',
  styleUrls: ['./fra-sales-credit.component.css']
})
export class FraSalesCreditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

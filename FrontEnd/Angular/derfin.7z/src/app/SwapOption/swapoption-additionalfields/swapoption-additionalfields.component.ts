import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-swapoption-additionalfields',
  templateUrl: './swapoption-additionalfields.component.html',
  styleUrls: ['./swapoption-additionalfields.component.css']
})
export class SwapoptionAdditionalfieldsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

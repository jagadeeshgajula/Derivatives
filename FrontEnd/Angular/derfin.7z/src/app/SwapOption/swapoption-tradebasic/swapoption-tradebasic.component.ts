import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-swapoption-tradebasic',
  templateUrl: './swapoption-tradebasic.component.html',
  styleUrls: ['./swapoption-tradebasic.component.css']
})
export class SwapoptionTradebasicComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

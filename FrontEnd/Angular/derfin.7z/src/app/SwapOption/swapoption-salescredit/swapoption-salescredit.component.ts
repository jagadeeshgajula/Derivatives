import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-swapoption-salescredit',
  templateUrl: './swapoption-salescredit.component.html',
  styleUrls: ['./swapoption-salescredit.component.css']
})
export class SwapoptionSalescreditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-swapoption-fees',
  templateUrl: './swapoption-fees.component.html',
  styleUrls: ['./swapoption-fees.component.css']
})
export class SwapoptionFeesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

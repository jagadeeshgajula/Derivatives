import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-swapoption-assignment',
  templateUrl: './swapoption-assignment.component.html',
  styleUrls: ['./swapoption-assignment.component.css']
})
export class SwapoptionAssignmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

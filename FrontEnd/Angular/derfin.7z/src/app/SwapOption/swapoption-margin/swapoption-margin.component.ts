import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-swapoption-margin',
  templateUrl: './swapoption-margin.component.html',
  styleUrls: ['./swapoption-margin.component.css']
})
export class SwapoptionMarginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-swapoption-partialassignment',
  templateUrl: './swapoption-partialassignment.component.html',
  styleUrls: ['./swapoption-partialassignment.component.css']
})
export class SwapoptionPartialassignmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

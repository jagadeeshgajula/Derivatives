import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-UserEntitlement',
  templateUrl: './UserEntitlement.component.html',
  styleUrls: ['./UserEntitlement.component.css']
})
export class UserEntitlementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

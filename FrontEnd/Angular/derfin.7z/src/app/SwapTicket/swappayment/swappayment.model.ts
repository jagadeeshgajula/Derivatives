export class SwapPaymentModel{
cmbPayPayBusDay:any;
cntPayPayCalendars:any;
cmbPayPayFreqPnl:any;
cmbPayPayMarching:any;
cmbPayPaymentConvention:any;
cmbPayPaymentConversionCurrency:any;
cmbPayPaymentConversionIndex:any;
txtPayPaymentConversionLag:any;
cmbPayPayRollDay:any;
cmbPayRollWeek:any;
txtPayLag:any;

cmbRecPayBusDay:any;
cntRecPayCalendars:any;
cmbRecPayFreqPnl:any;
cmbRecPayMarching:any;
cmbRecPaymentConvention:any;
cmbRecPaymentConversionCurrency:any;
cmbRecPaymentConversionIndex:any;
txtRecPaymentConversionLag:any;
cmbRecPayRollDay:any;
cmbRecRollWeek:any;
txtRecLag:any;


    
}
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-margin',
  templateUrl: './margins.component.html',
  styleUrls: ['./margins.component.css']
})
export class MarginsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-additionalfields',
  templateUrl: './additionalfields.component.html',
  styleUrls: ['./additionalfields.component.css']
})
export class AdditionalfieldsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-salescredit',
  templateUrl: './salescredit.component.html',
  styleUrls: ['./salescredit.component.css']
})
export class SalescreditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

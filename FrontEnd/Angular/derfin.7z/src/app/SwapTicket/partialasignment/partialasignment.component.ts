import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-partialasignment',
  templateUrl: './partialasignment.component.html',
  styleUrls: ['./partialasignment.component.css']
})
export class PartialasignmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

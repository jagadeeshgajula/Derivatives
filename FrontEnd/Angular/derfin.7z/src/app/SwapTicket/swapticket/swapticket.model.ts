
export class SwapTicketModel{
    cmbPayCurrency:any;
    txtPayTenor:any;
    cmbRecCurrency:any;
    txtRecTenor:any;
    txtPayNotional:any;
    cmbPayNotionalExchange:any;
    txtRecNotional:any;
    cmbRecNotionalExchange:any;
    txtPayStartDate:any;
    txtPayStartStub:any;
    txtRecStartDate:any;
    txtRecStartStub:any;
    cmbPayStartDateRollFlag:any;
    cmbPayEndDateRollFlag:any;
    cmbRecStartDateRollFlag:any;
    cmbRecEndDateRollFlag:any;
    txtPayEndDate:any;
    txtPayEndStub:any;
    txtRecEndDate:any;
    txtRecEndStub:any;
    txtPayFrontstub:any;
    txtPayBackStub:any;
    txtRecFrontStub:any;
    legsPnl:any;
    txtPayFixedQuote:any;
    txtPayGearFactor:any;
    txtPaySpread:any;
    txtRecFixedQuote:any;
    txtRecGearQuote:any;
    txtRecSpread:any;
    cmbPayDayCount:any;
    cmbRecDayCount:any;
    cmbPayDiscountCurve:any;
    cmbRecDiscountCurve:any;
    cmbPayAccrualBusDay:any;
    cntPayAccrualCalendars:any;
    cmbRecAccrualBusDay:any;
    cntRecAccrualCalendars:any;
    cmbPayAccrualFreq:any;
    cmbPayAccrualMarching:any;
    cmbRecAccrualFreq:any;
    cmbRecAccrualMarching:any;
    cmbPayAccrualRollDay:any;
    cmbPayAccrualRollWeek:any;
    cmbPayEndOfMonthIndicator:any;
    cmbRecAccrualRollDay:any;
    cmbRecAccrualRollWeek:any;
    cmbRecEndOfMonthIndicator:any;
    cmbPayCompounding:any;
    cmbPayCompFreq:any;
    cmbRecCompounding:any;
    cmbRecCompFreq:any;
  txtRecGearFactor: any;
  currency: any;


    

}
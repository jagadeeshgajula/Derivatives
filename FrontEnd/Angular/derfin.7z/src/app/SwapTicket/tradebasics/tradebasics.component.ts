import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tradebasic',
  templateUrl: './tradebasics.component.html',
  styleUrls: ['./tradebasics.component.css']
})
export class TradebasicsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-margin',
  templateUrl: './margin.component.html',
  styleUrls: ['./margin.component.css']
})
export class MarginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-additional-fields',
  templateUrl: './additional-fields.component.html',
  styleUrls: ['./additional-fields.component.css']
})
export class AdditionalFieldsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

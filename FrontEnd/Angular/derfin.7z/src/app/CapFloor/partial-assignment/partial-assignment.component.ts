import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-partial-assignment',
  templateUrl: './partial-assignment.component.html',
  styleUrls: ['./partial-assignment.component.css']
})
export class PartialAssignmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

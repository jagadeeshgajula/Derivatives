import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-credit',
  templateUrl: './sales-credit.component.html',
  styleUrls: ['./sales-credit.component.css']
})
export class SalesCreditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

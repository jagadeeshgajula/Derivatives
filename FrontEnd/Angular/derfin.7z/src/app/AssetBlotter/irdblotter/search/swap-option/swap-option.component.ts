import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-swap-option',
  templateUrl: './swap-option.component.html',
  styleUrls: ['./swap-option.component.css']
})
export class SwapOptionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fra',
  templateUrl: './fra.component.html',
  styleUrls: ['./fra.component.css']
})
export class FraComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

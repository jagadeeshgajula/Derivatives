import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cap-floor',
  templateUrl: './cap-floor.component.html',
  styleUrls: ['./cap-floor.component.css']
})
export class CapFloorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-irdblotter',
  templateUrl: './irdblotter.component.html',
  styleUrls: ['./irdblotter.component.css']
})
export class IRDBlotterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
